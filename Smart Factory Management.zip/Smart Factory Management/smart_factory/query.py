import sqlite3

def display_table(cursor, table_name):
    print(f"\n--- {table_name.upper()} ---")
    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()
    
    # Get column names
    column_names = [description[0] for description in cursor.description]
    print(f"Columns: {column_names}")
    
    for row in rows:
        print(row)
    
    if not rows:
        print("(Empty)")

if __name__ == "__main__":
    conn = sqlite3.connect('factory.db')
    cursor = conn.cursor()
    
    tables = ['production_lines', 'machines', 'telemetry', 'alerts']
    for table in tables:
        try:
            display_table(cursor, table)
        except sqlite3.OperationalError:
            print(f"\n--- {table.upper()} --- \nTable does not exist yet.")

    conn.close()