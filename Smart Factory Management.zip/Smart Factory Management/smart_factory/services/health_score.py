import models

def calculate_health_score(telemetry: models.Telemetry) -> tuple[int, str]:
    if not telemetry:
        return 0, "No Data"
        
    score = 100
    temp = telemetry.temperature
    vib = telemetry.vibration
    press = telemetry.pressure
    
    # Temperature penalties
    if temp > 80:
        score -= 20
    elif temp > 70:
        score -= 10
    elif temp < 20:
        score -= 5
        
    # Vibration penalties
    if vib > 5:
        score -= 20
    elif vib > 3:
        score -= 10
        
    # Pressure penalties
    if press > 6:
        score -= 20
    elif press > 5:
        score -= 10
    elif press < 1:
        score -= 5
        
    score = max(0, score)
    
    if score >= 80:
        status = "Healthy"
    elif score >= 50:
        status = "Warning"
    else:
        status = "Critical"
        
    return score, status