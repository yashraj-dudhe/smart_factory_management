import models
from sqlalchemy.orm import Session
from config import THRESHOLDS

def evaluate_thresholds(db: Session, telemetry: models.Telemetry):
    sensors = [
        ("temperature", telemetry.temperature),
        ("vibration", telemetry.vibration),
        ("pressure", telemetry.pressure)
    ]
    
    for sensor, value in sensors:
        th = THRESHOLDS.get(sensor, {})
        crit = th.get("critical", float('inf'))
        warn = th.get("warning", float('inf'))
        
        if value >= crit:
            alert = models.Alert(
                machine_id=telemetry.machine_id,
                alert_type=f"CRITICAL_{sensor.upper()}",
                sensor_value=value,
                threshold_value=crit
            )
            db.add(alert)
        elif value >= warn:
            alert = models.Alert(
                machine_id=telemetry.machine_id,
                alert_type=f"WARNING_{sensor.upper()}",
                sensor_value=value,
                threshold_value=warn
            )
            db.add(alert)
    db.commit()