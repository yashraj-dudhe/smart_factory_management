import requests
import random
import time
import sys

BASE_URL = "http://127.0.0.1:8000"

def get_machines():
    try:
        r = requests.get(f"{BASE_URL}/machines/")
        r.raise_for_status()
        return r.json()
    except Exception as e:
        print(f"Error fetching machines: {e}")
        return []

def simulate():
    machines = get_machines()
    if not machines:
        print("No machines found. Please create a machine first.")
        
        # Auto-create if none
        pl = requests.post(f"{BASE_URL}/production-lines/", json={"name": "Line 1", "description": "Auto-created"}).json()
        print(f"Created line: {pl}")
        m = requests.post(f"{BASE_URL}/machines/", json={"name": "SimMachine-1", "machine_type": "Pump", "production_line_id": pl['id']}).json()
        print(f"Created machine: {m}")
        machines = [m]
        
    print(f"Simulating for {len(machines)} machines...")
    while True:
        for m in machines:
            payload = {
                "machine_id": m["id"],
                "temperature": round(random.uniform(15.0, 95.0), 1),
                "vibration": round(random.uniform(0.0, 8.0), 1),
                "pressure": round(random.uniform(0.0, 9.0), 1)
            }
            try:
                r = requests.post(f"{BASE_URL}/telemetry/", json=payload)
                if r.status_code == 200:
                    print(f"Pushed: {payload}")
                else:
                    print(f"Failed to push: {r.text}")
            except Exception as e:
                print(f"Request failed: {e}")
        time.sleep(5)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        print("Run simulator without setup to see telemetry.")
    else:
        try:
            simulate()
        except KeyboardInterrupt:
            print("Simulator stopped.")