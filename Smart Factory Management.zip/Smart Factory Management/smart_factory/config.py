THRESHOLDS = {
    "temperature": {
        "warning": 70.0,
        "critical": 85.0
    },
    "vibration": {
        "warning": 3.0,
        "critical": 6.0
    },
    "pressure": {
        "warning": 5.0,
        "critical": 7.0
    }
}