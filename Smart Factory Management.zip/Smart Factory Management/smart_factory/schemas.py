from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class ProductionLineBase(BaseModel):
    name: str
    description: Optional[str] = None

class ProductionLineCreate(ProductionLineBase):
    pass

class ProductionLine(ProductionLineBase):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class MachineBase(BaseModel):
    name: str
    machine_type: str
    production_line_id: int

class MachineCreate(MachineBase):
    pass

class Machine(MachineBase):
    id: int
    created_at: datetime
    class Config:
        orm_mode = True

class TelemetryBase(BaseModel):
    machine_id: int
    temperature: float
    vibration: float
    pressure: float

class TelemetryCreate(TelemetryBase):
    pass

class Telemetry(TelemetryBase):
    id: int
    recorded_at: datetime
    class Config:
        orm_mode = True

class AlertBase(BaseModel):
    machine_id: int
    alert_type: str
    sensor_value: float
    threshold_value: float

class AlertCreate(AlertBase):
    pass

class Alert(AlertBase):
    id: int
    is_resolved: bool
    created_at: datetime
    class Config:
        orm_mode = True
        
class HealthScoreResponse(BaseModel):
    machine_id: int
    health_score: int
    status: str

class MachineAnalytics(BaseModel):
    machine_id: int
    total_readings: int
    avg_temperature: float
    max_temperature: float
    total_alerts: int

class ProductionLineAnalytics(BaseModel):
    line_id: int
    total_machines: int
    total_alerts: int