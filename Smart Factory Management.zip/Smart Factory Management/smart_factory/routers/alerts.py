from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import models, schemas
from database import get_db

router = APIRouter(prefix="/alerts", tags=["Alerts"])

@router.get("/", response_model=List[schemas.Alert])
def read_active_alerts(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    alerts = db.query(models.Alert).filter(models.Alert.is_resolved == False).offset(skip).limit(limit).all()
    return alerts

@router.get("/{machine_id}", response_model=List[schemas.Alert])
def read_machine_alerts(machine_id: int, active_only: bool = True, db: Session = Depends(get_db)):
    query = db.query(models.Alert).filter(models.Alert.machine_id == machine_id)
    if active_only:
        query = query.filter(models.Alert.is_resolved == False)
    return query.all()

@router.patch("/{id}/resolve", response_model=schemas.Alert)
def resolve_alert(id: int, db: Session = Depends(get_db)):
    alert = db.query(models.Alert).filter(models.Alert.id == id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.is_resolved = True
    db.commit()
    db.refresh(alert)
    return alert