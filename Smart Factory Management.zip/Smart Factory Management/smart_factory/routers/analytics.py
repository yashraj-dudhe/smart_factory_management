from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
import models, schemas
from database import get_db

router = APIRouter(prefix="/analytics", tags=["Analytics"])

@router.get("/machines/{machine_id}", response_model=schemas.MachineAnalytics)
def get_machine_analytics(machine_id: int, db: Session = Depends(get_db)):
    machine = db.query(models.Machine).filter(models.Machine.id == machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
        
    tel_stats = db.query(
        func.count(models.Telemetry.id).label("total_readings"),
        func.avg(models.Telemetry.temperature).label("avg_temp"),
        func.max(models.Telemetry.temperature).label("max_temp")
    ).filter(models.Telemetry.machine_id == machine_id).first()
    
    alerts = db.query(func.count(models.Alert.id)).filter(models.Alert.machine_id == machine_id).scalar()
    
    return {
        "machine_id": machine_id,
        "total_readings": tel_stats.total_readings or 0,
        "avg_temperature": round(tel_stats.avg_temp or 0.0, 2),
        "max_temperature": round(tel_stats.max_temp or 0.0, 2),
        "total_alerts": alerts or 0
    }

@router.get("/production-lines/{line_id}", response_model=schemas.ProductionLineAnalytics)
def get_line_analytics(line_id: int, db: Session = Depends(get_db)):
    line = db.query(models.ProductionLine).filter(models.ProductionLine.id == line_id).first()
    if not line:
        raise HTTPException(status_code=404, detail="Line not found")
        
    machines = db.query(models.Machine.id).filter(models.Machine.production_line_id == line_id).all()
    machine_ids = [m.id for m in machines]
    
    alert_count = 0
    if machine_ids:
        alert_count = db.query(func.count(models.Alert.id)).filter(models.Alert.machine_id.in_(machine_ids)).scalar()
        
    return {
        "line_id": line_id,
        "total_machines": len(machine_ids),
        "total_alerts": alert_count or 0
    }