from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import models, schemas
from database import get_db

router = APIRouter(prefix="/production-lines", tags=["Production Lines"])

@router.post("/", response_model=schemas.ProductionLine)
def create_production_line(pl: schemas.ProductionLineCreate, db: Session = Depends(get_db)):
    db_pl = models.ProductionLine(**pl.dict())
    db.add(db_pl)
    db.commit()
    db.refresh(db_pl)
    return db_pl

@router.get("/", response_model=List[schemas.ProductionLine])
def read_production_lines(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    lines = db.query(models.ProductionLine).offset(skip).limit(limit).all()
    return lines

@router.get("/{id}", response_model=schemas.ProductionLine)
def read_production_line(id: int, db: Session = Depends(get_db)):
    line = db.query(models.ProductionLine).filter(models.ProductionLine.id == id).first()
    if line is None:
        raise HTTPException(status_code=404, detail="Production line not found")
    return line