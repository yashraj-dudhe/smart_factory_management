from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import models, schemas
from database import get_db
from services.health_score import calculate_health_score

router = APIRouter(prefix="/machines", tags=["Machines"])

@router.post("/", response_model=schemas.Machine)
def create_machine(machine: schemas.MachineCreate, db: Session = Depends(get_db)):
    db_mach = models.Machine(**machine.dict())
    db.add(db_mach)
    db.commit()
    db.refresh(db_mach)
    return db_mach

@router.get("/", response_model=List[schemas.Machine])
def read_machines(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    machines = db.query(models.Machine).offset(skip).limit(limit).all()
    return machines

@router.get("/{id}", response_model=schemas.Machine)
def read_machine(id: int, db: Session = Depends(get_db)):
    machine = db.query(models.Machine).filter(models.Machine.id == id).first()
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine

@router.get("/{machine_id}/health", response_model=schemas.HealthScoreResponse)
def read_machine_health(machine_id: int, db: Session = Depends(get_db)):
    machine = db.query(models.Machine).filter(models.Machine.id == machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
        
    latest_telemetry = db.query(models.Telemetry).filter(models.Telemetry.machine_id == machine_id).order_by(models.Telemetry.recorded_at.desc()).first()
    
    score, status = calculate_health_score(latest_telemetry)
    return {"machine_id": machine_id, "health_score": score, "status": status}