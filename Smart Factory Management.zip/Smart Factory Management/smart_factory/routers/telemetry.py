from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import models, schemas
from database import get_db
from services.alert_engine import evaluate_thresholds

router = APIRouter(prefix="/telemetry", tags=["Telemetry"])

@router.post("/", response_model=schemas.Telemetry)
def create_telemetry(telemetry: schemas.TelemetryCreate, db: Session = Depends(get_db)):
    db_tel = models.Telemetry(**telemetry.dict())
    db.add(db_tel)
    db.commit()
    db.refresh(db_tel)
    
    # Evaluate thresholds to auto-generate alerts
    evaluate_thresholds(db, db_tel)
    
    return db_tel

@router.get("/{machine_id}", response_model=List[schemas.Telemetry])
def read_telemetry(machine_id: int, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    telemetry = db.query(models.Telemetry).filter(models.Telemetry.machine_id == machine_id).order_by(models.Telemetry.recorded_at.desc()).offset(skip).limit(limit).all()
    return telemetry

@router.get("/{machine_id}/latest", response_model=schemas.Telemetry)
def read_latest_telemetry(machine_id: int, db: Session = Depends(get_db)):
    telemetry = db.query(models.Telemetry).filter(models.Telemetry.machine_id == machine_id).order_by(models.Telemetry.recorded_at.desc()).first()
    if not telemetry:
        raise HTTPException(status_code=404, detail="Telemetry not found")
    return telemetry