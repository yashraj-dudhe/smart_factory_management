from fastapi import FastAPI
import models
from database import engine
from routers import production_lines, machines, telemetry, alerts, analytics

# Create tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Smart Factory Monitoring & Predictive Maintenance System", version="1.0")

app.include_router(production_lines.router)
app.include_router(machines.router)
app.include_router(telemetry.router)
app.include_router(alerts.router)
app.include_router(analytics.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to Smart Factory Monitoring API. Visit /docs for Swagger UI."}