# Smart Factory Monitoring & Predictive Maintenance System

## 1. Introduction
The Smart Factory Monitoring & Predictive Maintenance System is a lightweight Minimum Viable Product (MVP) backend built with Python (FastAPI) and SQLite. It provides a centralized API designed to register factory machinery, collect simulated sensor telemetry (temperature, vibration, pressure), process this data to evaluate machine health scores, and generate automated alerts when a machine's sensors report values exceeding predefined limits. 

The primary goal of this application is tracking the operational health of machines and issuing early-warning alerts for predictive maintenance, reducing unexpected downtime.

---

## 2. System Architecture
The application architecture strictly follows a traditional lightweight 3-tier MVC/MVP pattern (Model-View-Controller, where the "View" is our JSON API).

```mermaid
graph TD
    %% Define components
    Sim[IoT Simulator Script]
    API[FastAPI Gateway / Routers]
    
    %% Services layer
    AlertSvc[Alert Engine Service]
    HealthSvc[Health Score Service]
    
    %% Data layer
    ORM[SQLAlchemy ORM]
    DB[(SQLite Database)]
    
    %% Connections
    Sim -- "POST /telemetry/" --> API
    API -- "CRUD Queries" --> ORM
    API -- "Evaluates Values" --> AlertSvc
    API -- "Requests Score" --> HealthSvc
    
    AlertSvc -- "Triggers Threshold Logic" --> ORM
    HealthSvc -- "Calculates Penalties" --> ORM
    
    ORM <--> DB
```

1. **Client / IoT Layer:** Represented by `simulator.py`, acting as the edge devices constantly polling sensors and sending data over HTTP.
2. **Application Layer (FastAPI):** `main.py` routing requests to specific controllers (`routers/*.py`) while Pydantic rigorously validates request/response shapes.
3. **Business Logic Layer:** The `services/` directory intercepts critical tasks like penalizing machine scores (`health_score.py`) and trapping anomalies (`alert_engine.py`).
4. **Data Access Layer:** `database.py` and `models.py` abstract the database interactions using SQLAlchemy.
5. **Storage Layer:** A lightweight local `factory.db` SQLite file holds persistent telemetry and configurations securely.

---

## 3. File & Directory Structure
The workspace is organized inside the `smart_factory/` directory to separate API routing, business logic, configuration, and data models cleanly:

```text
smart_factory/
│
├── routers/                 # FastAPI router endpoints (Controllers)
│   ├── alerts.py            # API logic for viewing and resolving alerts
│   ├── analytics.py         # API logic for aggregated health statistics
│   ├── machines.py          # API logic to register/query machines & fetch health scores
│   ├── production_lines.py  # API logic for registering/querying production lines
│   └── telemetry.py         # API logic for ingesting and reading sensor data
│
├── services/                # Core business logic processing (Models/Services)
│   ├── alert_engine.py          # Checks readings against thresholds to trip "CRITICAL" / "WARNING" states
│   └── health_score.py          # Algorithm defining penalty-point deductions for the 0-100 score rules
│
├── tests/                   # Pytest automation suite asserting the API functionality
│   ├── conftest.py          # Pytest configuration mocking databases via TestClient
│   ├── test_api.py          # Tests end-to-end API HTTP calls
│   └── test_logic.py        # Validates math inside health_score calculation
│
├── config.py                # Configurations defining global warning/critical constants
├── database.py              # System connection configurations pointing to localized SQLite factory.db
├── main.py                  # Standard FastAPI start-up entry routing and schema construction
├── models.py                # SQLAlchemy ORM specifications for creating DB Tables
├── query.py                 # Custom diagnostic CLI script dropping outputs about Table Content. 
├── schemas.py               # Pydantic schemas validating shape for incoming Requests & Reponses.
├── simulator.py             # Automates infinite mock sensor requests pushing HTTP payload loop
└── requirements.txt         # Project Dependencies
```

---

## 4. Core System Flow
1. **Registration:** You establish the hierarchy by sending a `POST` request to create a Production Line, followed by your Machines.
2. **Telemetry Ingestion:** The `simulator.py` continuously POSTs random telemetry payloads to `/telemetry/`. The DB records the incoming data attached to the Machine's ID.
3. **Threshold Analysis:** Every injected telemetry packet runs through `alert_engine.py`. If temperature, vibration, or pressure breaches rules configured in `config.py`, an alert record is written to the database automatically.
4. **Health Evaluation:** Requesting `/machines/{id}/health` pulls the *latest* telemetry record and executes `health_score.py`, deducing a penalty-driven score from 100 based on standard limits returning Status: Healthy / Warning / Critical.

---

## 5. API Endpoints

### Production Lines (`routers/production_lines.py`)
- `POST /production-lines/` - Creates a new production line.
- `GET /production-lines/` - Lists all lines.
- `GET /production-lines/{id}` - Retrieve details of a specific line.

### Machines (`routers/machines.py`)
- `POST /machines/` - Registers a machine to a production line.
- `GET /machines/` - Lists all registered machinery.
- `GET /machines/{id}/health` - Computes and returns the 0-100 `HealthScoreResponse` based on their most recent data.

### Telemetry (`routers/telemetry.py`)
- `POST /telemetry/` - Saves new sensor readings (temperature, vibration, pressure) and internally calls the Alert Engine.
- `GET /telemetry/{machine_id}` - Fetches the historical log of telemetry for a machine.
- `GET /telemetry/{machine_id}/latest` - Retrieves the single most recent telemetry packet.

### Alerts (`routers/alerts.py`)
- `GET /alerts/` - Lists all active (unresolved) tracking alerts triggered by the engine.
- `GET /alerts/{machine_id}` - Looks up active alerts for a specific machine.
- `PATCH /alerts/{id}/resolve` - Closes out an alert by modifying `is_resolved` to True.

### Analytics (`routers/analytics.py`)
- `GET /analytics/machines/{machine_id}` - Returns aggregate stat insights (avg temp, max temp, total alerts, etc) utilizing SQL math for a target machine.
- `GET /analytics/production-lines/{line_id}` - Aggregates counts of items tied to the production chain. 

---

## 6. Database Schema
Information is persisted using **SQLite** with the help of **SQLAlchemy ORM**. The schemas generated in `models.py` include:
1. `production_lines`: The primary organizing grouping table holding general descriptions.
2. `machines`: Maps hardware records linking up to `production_lines` via Foreign Key.
3. `telemetry`: A heavy recording table logging sensor values over timestamps.
4. `alerts`: A lightweight flag table generated defensively storing breached thresholds until users mark them conceptually safe.

---

## 7. How to Setup and Run

### Installing Prerequisites
Make sure you are utilizing Python 3.10+ (Preferably stable 3.11/3.12 or running via the Pydantic V1 downgrade provided)
```bash
pip install -r requirements.txt
```

### Launching the Application
```bash
uvicorn main:app --reload
```
View Swagger UI documentation and execute APIs directly traversing: `http://127.0.0.1:8000/docs`

### Simulating Data
Open a secondary terminal:
```bash
python simulator.py
```
*(This script will query existing machines, auto-generate ones if none exist, and send realistic simulated anomalies simulating factory operations).*

### Validate through Automated Tests
The application is wrapped tightly utilizing PyTest environments overriding the DB to a localized `test_factory.db` verifying analytical boundaries.
```bash
pytest tests/ -W ignore
```