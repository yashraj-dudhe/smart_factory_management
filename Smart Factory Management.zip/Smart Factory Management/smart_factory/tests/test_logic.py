import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.health_score import calculate_health_score
import models

def test_calculate_health_score_healthy():
    t = models.Telemetry(temperature=50, vibration=2, pressure=4)
    score, status = calculate_health_score(t)
    assert score == 100
    assert status == "Healthy"

def test_calculate_health_score_warning():
    # temperature > 70 gives -10, vibration 4 gives -10
    t = models.Telemetry(temperature=75, vibration=4, pressure=4)
    score, status = calculate_health_score(t)
    assert score == 80  # This falls exactly on threshold, should be Healthy
    assert status == "Healthy"

    # push score below 80
    t = models.Telemetry(temperature=75, vibration=4, pressure=5.5) # -10, -10, -10 = 70
    score, status = calculate_health_score(t)
    assert score == 70
    assert status == "Warning"

def test_calculate_health_score_critical():
    t = models.Telemetry(temperature=90, vibration=6, pressure=2) # -20, -20
    score, status = calculate_health_score(t)
    assert score == 60
    assert status == "Warning"

    # make it critical
    t = models.Telemetry(temperature=90, vibration=8, pressure=8) # -20, -20, -20 = 40
    score, status = calculate_health_score(t)
    assert score == 40
    assert status == "Critical"
