def test_create_and_read_production_line(client):
    response = client.post("/production-lines/", json={"name": "Line 101"})
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Line 101"
    
    response = client.get("/production-lines/")
    assert response.status_code == 200
    assert len(response.json()) == 1

def test_machine_registration(client):
    pl = client.post("/production-lines/", json={"name": "Line 1"}).json()
    
    response = client.post("/machines/", json={
        "name": "Machine A",
        "machine_type": "CNC",
        "production_line_id": pl["id"]
    })
    
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Machine A"
    assert data["machine_type"] == "CNC"

def test_telemetry_and_health_and_alerts(client):
    pl = client.post("/production-lines/", json={"name": "Line A"}).json()
    m = client.post("/machines/", json={"name": "M A", "machine_type": "Pump", "production_line_id": pl["id"]}).json()
    m_id = m["id"]
    
    # Send normal reading
    client.post("/telemetry/", json={
        "machine_id": m_id,
        "temperature": 50,
        "vibration": 1,
        "pressure": 3
    })
    
    # Calculate health score
    health_resp = client.get(f"/machines/{m_id}/health")
    assert health_resp.status_code == 200
    assert health_resp.json()["status"] == "Healthy"
    assert health_resp.json()["health_score"] == 100
    
    # Send a critical reading to trigger alerts
    client.post("/telemetry/", json={
        "machine_id": m_id,
        "temperature": 100,  # CRITICAL threshold > 85
        "vibration": 8,      # CRITICAL threshold > 6
        "pressure": 3        # NORMAL
    })
    
    # Check Alerts
    alerts_resp = client.get("/alerts/")
    assert alerts_resp.status_code == 200
    alerts = alerts_resp.json()
    assert len(alerts) >= 1  # Should have triggered at least temp and vibration alerts

def test_analytics(client):
    pl = client.post("/production-lines/", json={"name": "Analytics Line"}).json()
    m = client.post("/machines/", json={"name": "Analytics M", "machine_type": "Mixer", "production_line_id": pl["id"]}).json()
    
    # Push 2 telemetry records
    client.post("/telemetry/", json={"machine_id": m["id"], "temperature": 40, "vibration": 2, "pressure": 3})
    client.post("/telemetry/", json={"machine_id": m["id"], "temperature": 60, "vibration": 2, "pressure": 3})
    
    # Check Machine Analytics
    ma_resp = client.get(f"/analytics/machines/{m['id']}")
    assert ma_resp.status_code == 200
    ma_data = ma_resp.json()
    assert ma_data["total_readings"] == 2
    assert ma_data["avg_temperature"] == 50.0
    assert ma_data["max_temperature"] == 60.0
    
    # Check Line Analytics
    la_resp = client.get(f"/analytics/production-lines/{pl['id']}")
    assert la_resp.status_code == 200
    la_data = la_resp.json()
    assert la_data["total_machines"] == 1