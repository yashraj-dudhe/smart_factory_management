# Product Requir ements Document (PRD)
## Smar t Factory Monit oring & Pr edictiv e Maintenance System
**Version:** 2.0
**Date:** June 2026
**Type:** MVP Back end System
**Status:** Dr aft
---
## 1. Pr oject Ov erview
The Smar t Factory Monit oring & Pr edictiv e Maintenance System is a lightweight MVP back end built with
FastAPI, SQL Alchemy (ORM), and SQLite (via P ython 's built-in `sqlite3` driv er). It allows a manufacturing
company t o register machines and pr oduction lines, simulate sensor telemetr y (temper ature, vibr ation,
pressur e), calculate a basic machine health scor e, gener ate thr eshold-based maintenance aler ts, ser ve
machine health dashboar d data via API, and pr ovide simple analytics r epor ts — all thr ough REST
endpoints. A utomated tests ar e written using p ytest with F astAPI' s TestClient.
---
## 2. Pr oblem Statement
A manufacturing company oper ates hundr eds of machines acr oss multiple pr oduction lines. Ther e is no
centr alized system t o track machine health in r eal time. F ailur es ar e disco vered only after downtime
begins, causing pr oduction dela ys and ﬁnancial losses. The company needs a simple back end system that
can detect early warning signs of machine deterior ation, sur face machine health status thr ough APIs, and
provide basic analytics on machine per formance o ver time.
---
## 3. Goals and Objectiv es
| Goal | Description |
|------|-------------|
| Centr alized Registr ation | Maintain a r egistr y of machines and pr oduction lines |
| Telemetr y Captur e | Simulate and st ore sensor r eadings per machine |
| Health Scoring | Compute a 0–100 health scor e from the latest sensor data |
| Aler t Gener ation | Flag machines that ex ceed saf e oper ating thr esholds |
| Dashboar d API | Ser ve machine health summar y data consumable b y any client |
| Analytics Repor ts | Pr ovide basic aggr egated stats per machine and pr oduction line |
| Automated Testing | Co ver all cor e endpoints and logic with p ytest test cases |
**Primar y Success Metric:** A de veloper can r egister a machine, simulate telemetr y, retrie ve a health
dashboar d, view analytics, and see aler ts — all via API — with all p ytest tests passing.
---
## 4. MVP Scope
The following ar e included in this MVP:
- Machine and pr oduction line r egistr ation (CRUD)
- Simulated telemetr y gener ation (temper ature, vibr ation, pr essur e)
- Telemetr y storage in SQLite via SQL Alchemy
- Basic health scor e calculation per machine (penalty-based, 0–100)
- Threshold-based aler t creation and r etrie val
- Machine health dashboar d API (summar y of all machines with scor es and status)
- Analytics r epor t APIs (a verages, aler t counts, worst-per forming machines)
- REST  API endpoints for all cor e oper ations
- Python simulat or script t o push fak e telemetr y
- Automated tests using p ytest + F astAPI TestClient
- Separ ate test database (`test.db`) isolated fr om pr oduction (`fact ory.db`)
---
## 5. Out of Scope
The following will **not** be built in this MVP:
- Machine learning or AI-based failur e prediction
- Real har dwar e / IoT  device integr ation
- Frontend dashboar d or UI of any kind
- User authentication or r ole-based access contr ol
- Multi-fact ory or multi-tenant ar chitectur e
- SMS, email, or push notiﬁcation deliv ery
- Complex tr end for ecasting or time-series analysis
- Enterprise deplo yment (Dock er, Kubernetes, cloud hosting)
- Data expor t (CSV , PDF) or BI t ool integr ations
- WebSock et or r eal-time str eaming
---
## 6. User Roles
For this MVP , ther e is a single act or — the **API Consumer** (de veloper or internal t ool):
| Role | Description |
|------|-------------|
| API Consumer | Registers machines, triggers simulations, queries health dashboar ds, analytics r epor ts,
and aler ts via REST  API. No authentication r equir ed for MVP . |
---
## 7. K ey Featur es
1. **Machine Registr y** — Register and list machines with name, type, and link ed pr oduction line.
2. **Pr oduction Line Registr y** — Register and list pr oduction lines.
3. **T elemetr y Simulat or** — P ython script (`simulat or.py`) that posts r andomiz ed sensor r eadings t o the
API in a loop.
4. **T elemetr y Storage** — All r eadings persisted in SQLite via SQL Alchemy with UT C timestamps.
5. **Health Scor e Engine** — Computes a 0–100 scor e per machine fr om its latest telemetr y recor d using
a penalty system.
6. **Aler t Engine** — A uto-creates aler t recor ds when sensor v alues br each warning or critical thr esholds.
7. **Machine Health Dashboar d API** — Single endpoint r eturning health summar y for all machines (scor e,
status, latest r eading).
8. **Analytics Repor t APIs** — Endpoints r eturning a verage sensor v alues, aler t counts, and worst-
performing machines per pr oduction line.
9. **A utomated Tests** — p ytest test suite co vering r egistr ation, telemetr y, health scor e, aler ts, dashboar d,
and analytics using a dedicated test database.
---
## 8. F unctional Requir ements
### 8.1 Machine & Pr oduction Line Management
- **FR-01:** The system shall allow r egistering a new pr oduction line with a name and description.
- **FR-02:** The system shall allow r egistering a machine with a name, type, and associated pr oduction
line ID .
- **FR-03:** The system shall allow listing all machines and all pr oduction lines.
- **FR-04:** The system shall allow f etching a single machine or pr oduction line b y ID.
### 8.2 Telemetr y
- **FR-05:** The system shall accept telemetr y readings for a machine: `temper ature` (°C ), `vibr ation`
(mm/s), `pr essur e` (bar).
- **FR-06:** Each telemetr y recor d shall st ore the machine ID and a UT C timestamp.
- **FR-07:** A simulat or script shall gener ate r andomiz ed readings and POST  them t o the telemetr y
endpoint in a conﬁgur able loop.
- **FR-08:** The system shall allow f etching full telemetr y hist ory for a machine.
- **FR-09:** The system shall allow f etching only the latest telemetr y reading for a machine.
### 8.3 Health Scor e
- **FR-10:** The system shall calculate a health scor e (0–100) per machine based on its most r ecent
telemetr y recor d.
- **FR-11:** The health scor e shall be r etrie vable per machine via API.
- **FR-12:** Scor e labels: 80–100 = Healthy , 50–79 = W arning, 0–49 = Critical.
### 8.4 Aler ts
- **FR-13:** The system shall aut omatically e valuate e very incoming telemetr y reading against deﬁned
thresholds.
- **FR-14:** If a thr eshold is br eached, the system shall cr eate an aler t recor d with: machine ID , aler t type,
sensor v alue, thr eshold v alue, and timestamp.
- **FR-15:** The system shall list all activ e (unr esolv ed) aler ts globally and per machine.
- **FR-16:** The system shall allow marking an aler t as r esolv ed.
### 8.5 Machine Health Dashboar d API
- **FR-17:** The system shall pr ovide a dashboar d endpoint that r eturns a summar y list of all machines
including: machine name, pr oduction line name, latest health scor e, status label, and count of activ e aler ts.
- **FR-18:** The system shall pr ovide a per-machine dashboar d endpoint r eturning: machine details, latest
telemetr y reading, curr ent health scor e, status, and activ e aler t count.
### 8.6 Analytics Repor ts
- **FR-19:** The system shall pr ovide an analytics endpoint per machine r eturning: a verage temper ature,
average vibr ation, a verage pr essur e, total telemetr y recor ds, and t otal aler ts trigger ed — all computed fr om
historical data.
- **FR-20:** The system shall pr ovide a pr oduction line summar y endpoint r eturning: t otal machines, count
of machines b y status (Healthy / W arning / Critical), and t otal activ e aler ts acr oss the line.
- **FR-21:** The system shall pr ovide a " worst per forming machines" endpoint r eturning the t op N
machines r anked b y lowest health scor e.
### 8.7 A utomated Testing
- **FR-22:** A p ytest test suite shall co ver all cor e endpoints.
- **FR-23:** Tests shall use a separ ate SQLite test database (`test.db`) via F astAPI dependency o verride.
- **FR-24:** Tests shall be runnable with a single `p ytest` command fr om the pr oject r oot.
---
## 9. Non-F unctional Requir ements
| Requir ement | Target |
|-------------|--------|
| Response Time | API r esponses under 500ms for all endpoints |
| Database | SQLite via P ython built-in `sqlite3` driv er, managed thr ough SQL Alchemy ORM |
| Language | P ython 3.10+ |
| Framework | F astAPI |
| ORM | SQL Alchemy (Cor e + ORM) |
| Testing | p ytest + http x (FastAPI TestClient) |
| Data P ersistence | All data st ored on disk in `fact ory.db`; test data in `test.db` |
| Code Quality | Modular structur e: separ ate ﬁles per concern (models, schemas, r outers, ser vices) |
| Documentation | A uto-gener ated Swagger UI at `/docs` and ReDoc at `/r edoc` |
| Portability | Runs locally with `pip install -r r equir ements.txt` + `uvicorn main:app` |
---
## 10. Basic Data Model
### Table: `pr oduction_lines`
| Column | Type | Notes |
|--------|------|-------|
| id | IN TEGER (PK) | A uto-incr ement |
| name | TEXT  | e.g., "Line A " |
| description | TEXT  | Optional |
| created_at | D ATETIME | UT C |
### Table: `machines`
| Column | Type | Notes |
|--------|------|-------|
| id | IN TEGER (PK) | A uto-incr ement |
| name | TEXT  | e.g., "CNC-01" |
| machine_type | TEXT  | e.g., "CNC", "Pr ess", "Conv eyor" |
| production_line_id | IN TEGER (FK) | Ref erences pr oduction_lines |
| created_at | D ATETIME | UT C |
### Table: `telemetr y`
| Column | Type | Notes |
|--------|------|-------|
| id | IN TEGER (PK) | A uto-incr ement |
| machine_id | IN TEGER (FK) | Ref erences machines |
| temper ature | REAL | °C |
| vibr ation | REAL | mm/s |
| pressur e | REAL | bar |
| recor ded_at | D ATETIME | UT C |
### Table: `aler ts`
| Column | Type | Notes |
|--------|------|-------|
| id | IN TEGER (PK) | A uto-incr ement |
| machine_id | IN TEGER (FK) | Ref erences machines |
| aler t_type | TEXT  | e.g., "CRI TICAL_TEMPERA TURE", "W ARNING_VIBRA TION" |
| sensor_v alue | REAL | The v alue that trigger ed the aler t |
| threshold_v alue | REAL | The thr eshold that was cr ossed |
| is_r esolv ed | BOOLEAN | Default: F alse |
| created_at | D ATETIME | UT C |
---
## 11. API List
### Pr oduction Lines
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST  | `/pr oduction-lines/` | Register a new pr oduction line |
| GET | `/pr oduction-lines/` | List all pr oduction lines |
| GET | `/pr oduction-lines/{id}` | Get a pr oduction line b y ID |
### Machines
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST  | `/machines/` | Register a new machine |
| GET | `/machines/` | List all machines |
| GET | `/machines/{id}` | Get a machine b y ID |
### Telemetr y
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST  | `/telemetr y/` | Submit a new telemetr y reading |
| GET | `/telemetr y/{machine_id}` | Get full telemetr y hist ory for a machine |
| GET | `/telemetr y/{machine_id}/latest` | Get the most r ecent r eading for a machine |
### Health Scor e
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/machines/{machine_id}/health` | Get health scor e and status for a machine |
### Aler ts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/aler ts/` | List all activ e (unr esolv ed) aler ts |
| GET | `/aler ts/{machine_id}` | Get all aler ts for a speciﬁc machine |
| PATCH | `/aler ts/{id}/r esolv e` | Mark an aler t as r esolv ed |
### Machine Health Dashboar d
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/dashboar d/` | Summar y of all machines: name, line, scor e, status, aler t count |
| GET | `/dashboar d/{machine_id}` | F ull health summar y for a single machine |
### Analytics Repor ts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/analytics/machines/{machine_id}` | A vg sensor v alues, t otal r eadings, t otal aler ts for a machine |
| GET | `/analytics/pr oduction-lines/{line_id}` | Machine count b y status, t otal aler ts for a pr oduction line |
| GET | `/analytics/worst-machines?limit=5` | Top N machines r anked b y lowest health scor e |
**Total: 19 endpoints** — distributed acr oss 5 da ys.
---
## 12. Health Scor e Logic
The health scor e uses a penalty system applied t o the most r ecent telemetr y recor d. Star t at 100 and
deduct points based on how far each sensor de viates fr om its saf e range.
### Saf e Ranges
| Sensor | Saf e Range |
|--------|-----------|
| Temper ature | 20°C – 80°C |
| Vibr ation | 0 – 5 mm/s |
| Pressur e | 1 – 6 bar |
### P enalty Rules
```python
scor e = 100
# Temper ature
if temper ature > 80:
    scor e -= 20
elif temper ature > 70:
    scor e -= 10
elif temper ature < 20:
    scor e -= 5
# Vibr ation
if vibr ation > 5:
    scor e -= 20
elif vibr ation > 3:
    scor e -= 10
# Pressur e
if pressur e > 6:
    scor e -= 20
elif pr essur e > 5:
    scor e -= 10
elif pr essur e < 1:
    scor e -= 5
scor e = max(0, scor e)  # ﬂoor at 0
```
### Scor e Labels
| Scor e Range | Status |
|-------------|--------|
| 80 – 100 | ✅  Healthy |
| 50 – 79 | ⚠  Warning |
| 0 – 49 | 🔴  Critical |
---
## 13. Aler t Logic
Alerts ar e gener ated aut omatically inside `POST  /telemetr y/` immediately after the r eading is sa ved. Each
sensor is check ed independently .
### Aler t Thresholds
| Sensor | W arning Threshold | Critical Threshold |
|--------|------------------|--------------------|
| Temper ature | > 70°C | > 85°C |
| Vibr ation | > 3 mm/s | > 6 mm/s |
| Pressur e | > 5 bar | > 7 bar |
### Aler t Creation Rule
```python
for sensor , value, warn, crit in sensors:
    if v alue >= crit:
        cr eate_aler t(type=f "CRITICAL_{sensor}", v alue, thr eshold=crit)
    elif v alue >= warn:
        cr eate_aler t(type=f "WARNING_{sensor}", v alue, thr eshold=warn)
```
- One telemetr y reading can gener ate up t o 3 aler ts (one per sensor).
- Every breach cr eates a new aler t recor d — no deduplication in MVP .
- Aler ts sta y activ e (`is_r esolv ed = F alse`) until r esolv ed via API.
---
## 14. Dashboar d API Response F ormat
### `GE T /dashboar d/`
Returns a ﬂat list of all machines with their curr ent health summar y:
```json
[
  {
    "machine_id": 1,
    "machine_name ": "CNC-01",
    "machine_type ": "CNC",
    "production_line ": "Line A ",
    "health_scor e": 75,
    "status": "W arning",
    "activ e_aler ts": 2,
    "last_r eading_at": "2026-06-01T10:30:00Z"
  }
]
```
### `GE T /dashboar d/{machine_id}`
Returns full detail for a single machine:
```json
{
  "machine_id": 1,
  "machine_name ": "CNC-01",
  "production_line ": "Line A ",
  "health_scor e": 75,
  "status": "W arning",
  "activ e_aler ts": 2,
  "latest_telemetr y": {
    "temper ature": 74.5,
    "vibr ation ": 3.2,
    "pressur e": 4.1,
    "recor ded_at": "2026-06-01T10:30:00Z"
  }
}
```
---
## 15. Analytics Repor t Logic
All analytics ar e computed liv e from SQLite using SQL Alchemy aggr egate queries — no caching in MVP .
### `GE T /analytics/machines/{machine_id}`
Queries the `telemetr y` table and `aler ts` table for the giv en machine:
```python
AVG(temper ature), A VG(vibr ation), A VG(pr essur e),
COUN T(telemetr y rows),
COUN T(aler t rows WHERE machine_id = id)
```
**Sample Response:**
```json
{
  "machine_id": 1,
  "machine_name ": "CNC-01",
  "total_r eadings": 120,
  "avg_temper ature": 68.4,
  "avg_vibr ation ": 2.9,
  "avg_pr essur e": 4.2,
  "total_aler ts": 14
}
```
### `GE T /analytics/pr oduction-lines/{line_id}`
Groups all machines on the line b y their curr ent health status:
```json
{
  "production_line ": "Line A ",
  "total_machines": 5,
  "healthy ": 3,
  "warning": 1,
  "critical": 1,
  "total_activ e_aler ts": 6
}
```
### `GE T /analytics/worst-machines?limit=5`
Returns t op N machines sor ted b y lowest health scor e (ascending):
```json
[
  { "machine_id": 3, " name ": "Pr ess-02", "health_scor e": 35, " status": "Critical" },
  { "machine_id": 7, " name ": "CNC-04", "health_scor e": 55, " status": "W arning" }
]
```
---
## 16. Testing Str ategy (p ytest)
### Setup — `conftest.p y`
A shar ed ﬁxtur e overrides the pr oduction database with a test-speciﬁc SQLite ﬁle (`test.db`):
```python
SQLALCHEM Y_TEST_URL = " sqlite:/ //./test.db "
engine = cr eate_engine(SQL ALCHEM Y_TEST_URL,
                       connect_ar gs={" check_same_thr ead": F alse})
TestingSessionLocal = sessionmak er(bind=engine)
def o verride_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    ﬁnally:
        db.close()
app.dependency_o verrides[get_db] = o verride_get_db
Base.metadata.cr eate_all(bind=engine)
client = TestClient(app)
```
### Test Files
| File | What It Tests |
|------|--------------|
| `test_pr oduction_lines.p y` | Cr eate and r etrie ve production lines |
| `test_machines.p y` | Register machines, link t o production lines |
| `test_telemetr y.py` | Submit r eadings, r etrie ve hist ory and latest |
| `test_health.p y` | Scor e = 100 for saf e readings; scor e drops for br eaches |
| `test_aler ts.py` | Aler t created on thr eshold br each; r esolv e aler t |
| `test_dashboar d.py` | Dashboar d returns corr ect machine summaries |
| `test_analytics.p y` | A verages corr ect; pr oduction line status counts corr ect |
### Sample Test Cases
```python
# test_health.p y
def test_healthy_scor e():
    # Saf e telemetr y should r eturn scor e 100
    client.post("/telemetr y/", json={
        " machine_id": 1, "temper ature": 50,
        "vibr ation ": 2.0, " pressur e": 3.0
    })
    r = client.get("/machines/1/health ")
    asser t r.json()[" scor e"] == 100
    asser t r.json()[" status"] == "Healthy "
def test_critical_temper ature_lowers_scor e():
    client.post("/telemetr y/", json={
        " machine_id": 1, "temper ature": 90,
        "vibr ation ": 1.0, " pressur e": 2.0
    })
    r = client.get("/machines/1/health ")
    asser t r.json()[" scor e"] <= 49
    asser t r.json()[" status"] == "Critical"
# test_aler ts.py
def test_aler t_created_on_critical_temper ature():
    client.post("/telemetr y/", json={
        " machine_id": 1, "temper ature": 90,
        "vibr ation ": 1.0, " pressur e": 2.0
    })
    aler ts = client.get("/aler ts/").json()
    asser t any(a[" alert_type "] == "CRI TICAL_TEMPERA TURE" for a in aler ts)
def test_r esolv e_aler t():
    aler ts = client.get("/aler ts/").json()
    aler t_id = aler ts[0]["id"]
    r = client.patch(f "/aler ts/{aler t_id}/r esolv e")
    asser t r.status_code == 200
    asser t r.json()["is_r esolv ed"] == True
# test_dashboar d.py
def test_dashboar d_returns_all_machines():
    r = client.get("/dashboar d/")
    asser t r.status_code == 200
    asser t isinstance(r .json(), list)
    asser t "health_scor e" in r .json()[0]
    asser t "status" in r .json()[0]
```
Run all tests:
```bash
pytest
```
Run with v erbose output:
```bash
pytest -v
```
---
## 17. Assumptions
1. Sensor data is **simulated** — no r eal har dwar e is connected.
2. A single SQLite ﬁle (`fact ory.db`) is used for pr oduction; `test.db` is used for p ytest.
3. SQL Alchemy uses P ython 's built-in `sqlite3` driv er — no additional database installation needed.
4. No authentication is r equir ed for any API endpoint in the MVP .
5. All timestamps ar e stored and r eturned in **UT C**.
6. Thresholds ar e **har dcoded constants** in `conﬁg.p y` — no API t o change them.
7. Dashboar d and analytics data is computed on-the-ﬂy fr om SQLite — no caching.
8. Only the **most r ecent telemetr y recor d** is used t o compute health scor e.
9. A machine must exist befor e telemetr y can be submitted for it.
10. One de veloper or student is building this pr oject solo.
11. The pr oject runs on a local machine ( Windows / Mac / Linux) with P ython 3.10+.
---
## 18. 5-Da y De velopment Plan
| Day | Focus | Deliv erables |
|-----|-------|--------------|
| **Da y 1** | Pr oject Setup & Data La yer | F older structur e, `requir ements.txt`, SQL Alchemy + SQLite setup,
all 4 table models (`models.p y`), P ydantic schemas (`schemas.p y`), `conﬁg.p y` with thr esholds, database
init |
| **Da y 2** | Registr ation APIs + Telemetr y | `POST/GE T` for pr oduction lines and machines; `POST
/telemetr y/` with aler t aut o-gener ation; `GE T` telemetr y hist ory + latest |
| **Da y 3** | Health Scor e + Aler ts + Dashboar d | Health scor e ser vice + endpoint; aler ts list + r esolv e; `GE T
/dashboar d/` and `GE T /dashboar d/{id}` |
| **Da y 4** | Analytics + Simulat or | All 3 analytics endpoints; `simulat or.py` script; manual test of all 19
endpoints via Swagger UI |
| **Da y 5** | p ytest Suite + P olish | W rite all 7 test ﬁles; ﬁx bugs; `README.md` with setup, run, and test
instructions; ﬁnal cleanup |
### Pr oject Structur e
```
smar t_fact ory/
├──  main.p y                    # F astAPI app entr y point
├──  database.p y                # SQL Alchemy engine + session + Base
├──  models.p y                  # SQL Alchemy ORM table models
├──  schemas.p y                 # P ydantic r equest/r esponse schemas
├──  conﬁg.p y                  # Thresholds and sensor saf e ranges
├──  simulat or.py               # Telemetr y simulat or script
├──  routers/
│   ├──  production_lines.p y
│   ├──  machines.p y
│   ├──  telemetr y.py
│   ├──  aler ts.py
│   ├──  dashboar d.py
│   └──  analytics.p y
├──  services/
│   ├──  health_scor e.py        # P enalty-based scor e calculation
│   └──  aler t_engine.p y        # Threshold e valuation logic
├──  tests/
│   ├──  conftest.p y            # Test DB setup + shar ed client ﬁxtur e
│   ├──  test_pr oduction_lines.p y
│   ├──  test_machines.p y
│   ├──  test_telemetr y.py
│   ├──  test_health.p y
│   ├──  test_aler ts.py
│   ├──  test_dashboar d.py
│   └──  test_analytics.p y
├──  fact ory.db                 # SQLite pr oduction DB (aut o-created)
├──  test.db                    # SQLite test DB (aut o-created b y pytest)
├──  requir ements.txt
└──  README.md
```
### `r equir ements.txt`
```
fastapi
uvicorn
sqlalchemy
pydantic
httpx
pytest
```
No external database driv ers needed — `sqlite3` is built int o Python.
---
## 19. Acceptance Criteria
The MVP is complete when all of the following pass:
- [ ] **A C-01:** A pr oduction line can be r egister ed and r etrie ved via API.
- [ ] **A C-02:** A machine can be r egister ed under a pr oduction line and r etrie ved via API.
- [ ] **A C-03:** A telemetr y reading is accepted and persisted in `fact ory.db`.
- [ ] **A C-04:** Submitting a r eading abo ve the critical thr eshold aut o-creates an aler t.
- [ ] **A C-05:** `GE T /machines/{id}/health` r eturns a scor e (0–100) and a status label.
- [ ] **A C-06:** `GE T /aler ts/` r eturns all unr esolv ed aler ts.
- [ ] **A C-07:** An aler t can be r esolv ed via `P ATCH /aler ts/{id}/r esolv e`.
- [ ] **A C-08:** `GE T /dashboar d/` r eturns health summar y for all r egister ed machines.
- [ ] **A C-09:** `GE T /analytics/machines/{id}` r eturns corr ect a verage sensor v alues and aler t count.
- [ ] **A C-10:** `GE T /analytics/worst-machines` r eturns machines sor ted b y lowest scor e.
- [ ] **A C-11:** `simulat or.py` pushes multiple r eadings without err ors.
- [ ] **A C-12:** `p ytest` runs all tests and all pass with no err ors.
- [ ] **A C-13:** Swagger UI at `/docs` lists all 19 endpoints.
- [ ] **A C-14:** Pr oject runs fr om scr atch with only `pip install -r r equir ements.txt` + `uvicorn main:app`.
---
## 20. F uture Enhancements
Explicitly def erred — do not build in MVP:
| Enhancement | Description |
|-------------|-------------|
| ML-Based Pr ediction | scikit-learn model t o predict failur e probability fr om telemetr y trends |
| Email / SMS Aler ts | Notify staff via Twilio or SendGrid on critical aler ts |
| Frontend Dashboar d | React/V ue UI consuming the dashboar d and analytics APIs |
| User A uthentication | JW T-based auth with technician and admin r oles |
| Time-Series Trending | Detect degr adation patterns o ver rolling time windows |
| Multi-F actory Suppor t | Multi-tenant ar chitectur e for multiple fact ory locations |
| WebSock et Str eaming | Push r eal-time telemetr y events t o connected clients |
| Postgr eSQL Migr ation | Replace SQLite with P ostgr eSQL for pr oduction deplo yments |
| Data Expor t | CSV/PDF expor t of analytics r epor ts |
| Containerization | Dock er + dock er-compose for por table deplo yment |
---
*Document V ersion 2.0 — Updated t o include dashboar d APIs, analytics r epor ts, pytest testing str ategy ,
and SQL Alchemy + sqlite3 stack clariﬁcations.*
*Prepar ed for academic submission and pr actical implementation r eference.*